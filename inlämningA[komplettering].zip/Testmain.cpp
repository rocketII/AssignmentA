/*
 * Vi gör tester enligt handlednings dokumentet
 */

/* 
 * File:   Testmain.cpp
 * Author: root
 *
 * Created on den 5 februari 2016, 18:42
 */

#include <cstdlib>
#include "TestCellPhoneHandler.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv)
{
	/*
	 * int capacityArray = 2;
	 * TestCellPhoneHandler testObject(capacityArray);
	 * testObject.addPhone("nokia 313", 1, 2000);
	 * testObject.addPhone("Samsung Galaxy II", 1, 18000);
	 * 
	 * 
	 */
	

	return 0;
}

